% Animales %
es_animal(elefante).
es_animal(jirafa).
no_es_animal(telefono). %No se si es nesesario poner este ya que al no estar definido el telefono como es_animal se toma directamente como falso%

% Amigos %
es_amigo(juan,vianey).
es_amigo(armando,fernando).
es_amigo(jose,yael).

% Aprobar %
aprobo(abraham,inteligencia_artificial).
aprobo(diana,modelado_y_programacion).
reprobo(carlos,logica).
