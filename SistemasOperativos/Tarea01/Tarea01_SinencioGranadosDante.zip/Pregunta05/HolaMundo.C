#include <stdio.h>

main()
{
  printf("Hola mundo\n");
}
