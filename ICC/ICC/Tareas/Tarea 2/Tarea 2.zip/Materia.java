public class Materia{
  private String nombre;
  private String clave;
  private int creditos;
  
  public Materia(String n, String c, int cr){
    nombre = n;
    clave = c;
    creditos = cr;
  }
  
  public String toString(){
    String s = nombre + ", " + clave + ", " + creditos;
    return s;
  }
}