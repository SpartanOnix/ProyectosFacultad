/**
 * Modela un círculo en el plano cartesiano.
 * @author Miguel Mendoza.
 */
public class Circulo extends Figura implements FiguraI {
	
	private  double radio;
	private Punto centro;

	/**
	 * Crea un círculo con centro en (0,0) y radio 3.
	 */
	public Circulo(){
	}

	/**
	 * Construye un círculo con un centro y un radio dado.
	 * @param centro El centro del círculo.
	 * @param radio El radio del círculo.
	 * @throws ValorInvalidoExcepcion si el radio es negativo.
	 */
	public Circulo(Punto centro, double radio){
		
	}

	/**
	 * Constructor copia, construye un circulo a partir de otro.
	 * @param c El Circulo a copiar.
	 */
	public Circulo(Circulo c){
		
	}


	//Aquí va Método getPerimetro()

	/**
	 * Obtiene el área del triángulo. Fórmula de Herón.
	 * @return El área del triángulo.
	 */
	public double getArea(){
	}

	/**
	 * Mueve el círculo en el plano.
	 * @param deltaX El desplazamiento en el eje X.
	 * @param deltaY El desplazamiento en el eje Y.
	 * @throws DesplazamientoInvalido si los deltas son cero.
	 */
	public void mover(double deltaX, double deltaY){
	}

	/**
	 * En esta práctica, no tiene sentido rotar un círculo,
	 * por lo que no hace nada y se lanza una excepción.
	 * @throws UnsupportedOperationException Ya que no tiene sentido rotarlo.
	 */
	public void rotar90() throws UnsupportedOperationException{
		throw new UnsupportedOperationException("No tiene sentido rotar 90° el círculo.");
	}

	/**
	 * En esta práctica, no tiene sentido rotar un círculo,
	 * por lo que no hace nada y se lanza una excepción.
	 * @throws UnsupportedOperationException Ya que no tiene sentido rotarlo.
	 */
	public void rotar180()throws UnsupportedOperationException{
		throw new UnsupportedOperationException("No tiene sentido rotar 180° el círculo.");
	}

	/**
	 * Regresa el Punto con el centro.
	 * @return centro El centro del círculo.
	 */
	public Punto getCentro(){
	}

	/**
	 * Regresa el radio,
	 * @return radio el radio del círculo.
	 */
	public double getRadio(){
	}

	//Aquí va Método equals(Circulo c)



	/**
	 * Regresa los datos del triángulo.
	 */
	@Override
	public String toString(){
	}

}