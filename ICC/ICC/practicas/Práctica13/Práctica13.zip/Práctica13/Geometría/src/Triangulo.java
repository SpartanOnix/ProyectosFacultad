/**
 * Clase para crear triángulos en un plano cartesiano.
 * @author Miguel Mendoza.
 */
public class Triangulo extends Figura implements FiguraI{
	
	/**
	 * Constructor por omisión.
	 * Construye un triángulo en los puntos (0,0),(5,0),(2.5,2.5).
	 */
	public Triangulo(){
		super.lineas = new Linea[3];
		
	}

	/**
	 * Construye un triángulo dados 3 puntos del plano.
	 * @param p1 El punto 1
	 * @param p2 El punto 2
	 * @param p3 El punto 3
	 * @throws PuntosInvalidosExcepcion si los puntos son iguales.
	 */
	public Triangulo(Punto p1, Punto p2, Punto p3) throws PuntosInvalidosExcepcion{
		
	}

	/**
	 * Constructor copia. Construye un triángulo a partir de otro.
	 * @param t El triángulo del cual se creará uno nuevo.
	 * @throws NullPointerException si la figura es null.
	 */
	public Triangulo(Triangulo t) throws NullPointerException{
		
	}

	/**
	 * Obtiene el perímetro del triángulo.
	 * @return El perímetro. 
	 */
	public double getPerimetro(){
		
	}

	//Aquí va Método getArea()

	/**
	 * Mueve el triángulo en el plano.
	 * @param deltaX El desplazamiento en el eje X.
	 * @param deltaY El desplazamiento en el eje Y.
	 * @throws DesplazamientoInvalido si los deltas son cero.
	 */
	@Override
	public void mover(double deltaX, double deltaY){
		
	}

	//Aquí va Método rotar90()

	
	/**
	 * Rota el triángulo 180°.
	 */
	@Override
	public void rotar180(){
		
	}

	/**
	 * Nos dice si este triángulo es igual a otro.
	 * @param f La FiguraI a comparar.
	 * @return true si son iguales.
	 */
	public boolean equals(FiguraI f){		
	}

	/**
	 * Devuelve la linea 1.
	 * @return Linea 1 
	 */
	public Linea getL1(){
	}

	/**
	 * Devuelve la linea .
	 * @return Linea 2 
	 */
	public Linea getL2(){
	}

	/**
	 * Devuelve la linea 3.
	 * @return Linea 3. 
	 */
	public Linea getL3(){
	}

	/**
	 * Regresa los datos del triángulo.
	 */
	@Override
	public String toString(){
		
	}


}
