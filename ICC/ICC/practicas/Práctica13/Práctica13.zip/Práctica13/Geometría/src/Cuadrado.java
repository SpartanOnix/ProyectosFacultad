/**
 * Clase para crear cuadrados en un plano cartesiano.
 * @author Miguel Mendoza.
 */
public class Cuadrado extends Figura implements FiguraI {

	private int largo;
	
	/**
	 * Constructor por omisión.
	 * Construye un triángulo en los puntos (-3,3),(3,3),(-3,-3),(3,-3).
	 */
	public Cuadrado(){
		super.lineas = new Linea[4];		
	}
	
	/**
	 * Construye un Cuadrado con el centro en el Punto dado y del largo indicado.
	 * @param centro El centro del Cuadrado.
	 * @param largo El largo del Cuadrado.
	 * @throws ValorInvalidoExcepcion si el largo dado es negativo.
	 */
	public Cuadrado(Punto centro, int largo) throws ValorInvalidoExcepcion {
		
	}

	/**
	 * Constructor copia, construye un cuadrado a partir de otro.
	 * @param c El Cuadrado a copiar.
	 */
	public Cuadrado(Cuadrado c){
		
	}

	/**
	 * Obtiene el perímetro del cuandrado.
	 * @return El perímetro.
	 */
	@Override
	public double getPerimetro(){
	}

	//aquí va Método getArea()


	//Aqúí va Método rotar90()


	@Override
	public void rotar180(){
		
	}

	/**
	 * Mueve el cuadrado en el plano.
	 * @param deltaX El desplazamiento en el eje X.
	 * @param deltaY El desplazamiento en el eje Y.
	 * @throws DesplazamientoInvalido si los deltas son cero.
	 */
	@Override
	public void mover(double deltaX, double deltaY){
		
	}

	/**
	 * Nos dice si este cuadrado es igual a otro.
	 * @param f La FiguraI a comparar.
	 * @return true si son iguales.
	 */
	public boolean equals(FiguraI f){		
		
	}

	/**
	 * Devuelve la linea 1.
	 * @return Linea 1 
	 */
	public Linea getL1(){
	}

	/**
	 * Devuelve la linea .
	 * @return Linea 2 
	 */
	public Linea getL2(){
	}

	/**
	 * Devuelve la linea 3.
	 * @return Linea 3. 
	 */
	public Linea getL3(){
	}

	/**
	 * Devuelve la linea 4.
	 * @return Linea 4. 
	 */
	public Linea getL4(){
	}

	/**
	 * Obtiene el largo de un lado del cuadrado.
	 * @return largo El largo del cuadrado.
	 */
	public int getLargo(){
	}

	/**
	 * Regresa los datos del triángulo.
	 */
	@Override
	public String toString(){
	}

}