public class Millas2Kms {
	public static void main(String[] args) {
		double Millas = 202.0;
		double MILLAS_A_KILOMETROS = 1.609;		
		double Kilometros = Millas * MILLAS_A_KILOMETROS;
		System.out.println("***Convertir millas a kilometros***\n La distancia de Londres a Liverpool es de " + Millas + " millas que corresponden a " + Kilometros + " kilometros");
	}
}
