public class ConvertidorTemperatura {
	public static void main(String[] args) {

		
		double farenheit = 70.5;
		double celsius;
		celsius = 5.0/9.0 * (farenheit-32);
		System.out.println(celsius);
	}
}
