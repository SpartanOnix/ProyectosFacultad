public class Circulo {

	public static void main(String[] args) {
		//Variable flotante que contiene el valor de PI
		double pi = 3.1416;
		//Crear Variable para el radio del círculo
		double a = 2;
		double b = 5;
		double radio = a + b;
		System.out.println("El radio es: " + radio);
		//Crear variable y calcular el área
		double radiocuadrado = 7 * 7;
		System.out.println("El area es: " + pi * radiocuadrado);
		//Crear variable y calcular el perímetro
		double dospi = 3.1416 * 2;		
		System.out.println("El perimetro es: " + dospi * radio);
		//Imprimir el resultado

	}
}
