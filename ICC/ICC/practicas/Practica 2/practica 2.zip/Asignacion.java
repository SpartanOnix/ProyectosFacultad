public class Asignacion {
	
	public static void main(String[] args) {
		int a = 5;
		int b = 2;
		int c = 3;
		//El resto de tu código va aquí	
		double resultado1 = a + b + c + a * b + c;
		System.out.println("Resultado 1: " + resultado1); 
		double resultado2 = (a + b) * c;
		System.out.println("Resultado 2: " + resultado2); 
		double resultado3 = a + b * c;
		System.out.println("Resultado 3: " + resultado3); 
	}
}
