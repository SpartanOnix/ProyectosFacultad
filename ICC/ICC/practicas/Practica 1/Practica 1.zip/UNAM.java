public class UNAM{

    public static void main(String [] args){
	String a = "l";
	String b = "a";	
	String c = " unam";
	String d = " es la mejor universidad de";
	String e = " m";
	String f = "exico";
	String g = " y su lema es:";
	String h = "p";
	String i = "or mi raza hablara mi espiritu.";
	String j = "\nl";
	String k = "a facultad de ciencias tiene a los mejores estudiantes y a la mejor comida de la";
	System.out.println(a.toUpperCase() + b + c.toUpperCase() + d + e.toUpperCase() + f + g + h.toUpperCase() + i + j.toUpperCase() + k + c.toUpperCase());
	 
	}

} 
