public class Presentador{

    public static void main(String [] args){
	String a = "hola, soy dante estudio en la facultad de ciencias, en la carrera de ciencias de la computacion y tengo 17 años";
	System.out.println(a.toUpperCase());
	


    }
}
