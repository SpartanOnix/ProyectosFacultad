import java.io.*;
public class Tablero implements Serializable{
  
  public Tablero(int fila, int columna){
    int tablero [][]= new int[fila][columna];
    
  }
  
}