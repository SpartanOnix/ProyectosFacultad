public class Cuerpo extends Tablero{
  
    public Cuerpo(int fila, int columna){
    super(fila, columna);
  }

}