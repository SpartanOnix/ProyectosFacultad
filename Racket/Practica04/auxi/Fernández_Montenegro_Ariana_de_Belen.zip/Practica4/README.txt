Lenguajes de Programación.

README

Práctica 4.

Nombre:                               		Número de Cuenta:   		Correo:                    
Ariana de Belen Fernández Montenegro  		316087698           		arianafm@ciencias.unam.mx
Omar Fernando Gramer Muñoz			419003698			grameromar@ciencias.unam.mx
José Miguel Toledo Reyes			316164069			josemigueltr@ciencias.unam.mx


Instrucciones de uso:

Deberás tener DrRacket instalado; una vez ahí abrimos el archivo test.rkt, le damos "Run" y podremos probar los test de nuestra práctica.

