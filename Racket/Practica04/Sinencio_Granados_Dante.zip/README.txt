Nombre:                                No. de cuenta:   Correo-e:
Dante Jusepee Sinencio Granados        316246019        spartanonix@ciencias.unam.mx
Antonio Sandoval Mendoza               316075725        tonodx17@ciencias.unam.mx
Alejandro Cruz Jimenes                 316008488        alexcj71@ciencias.unam.mx