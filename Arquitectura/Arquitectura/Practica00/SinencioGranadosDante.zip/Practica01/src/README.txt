Sinencio Granados Dante Jusepee

El programa se ejecuta dando el siguiente comando a la altura de la
carpeta que contiene el .java:
ConvertidorDeBases.java bo bd num
donde bo es la base de origen, bd base de destino y num el numero a
convertir, un ejemplo puede ser "java ConvertidorDeBases 2 16 1101001011"

Preguntas:

1- El numero 172 convertido de base 10 a base 2 es: 10101100

2-Con 4 bits es suficiente ya que el 9 en binario se representa como
  1001

3-Con 5 bits es suficiente ya que el 22 en binario se representa como
  10110

4-Si es posible, lo único necesario es que para las bases mayores a
  10 definir bien sus transformaciones de letras a números
