package ed.estructuras.nolineales;

public class NodoAVL<C extends Comparable<C>> extends NodoBOLigado<C>{

  public NodoAVL(NodoBOLigado<C> hi, NodoBOLigado<C> p, C e, NodoBOLigado<C> hd){
    super( hi,  p,  e, hd);
  }

  public int getFB(){
    int altHI;
    int altHD;
    if(this.hijoI == null) altHI = 0;
    else altHI = hijoI.getAltura() + 1;
    if(this.hijoD == null) altHD = 0;
    else altHD = hijoD.getAltura() + 1;
    return altHI - altHD;
  }

  public NodoAVL<C> rotaRR(){
    NodoAVL <C> pd;
    NodoAVL <C> desva;
    NodoAVL <C> newp;
    NodoAVL <C> sub;
    if(this.papa != null){
      pd = (NodoAVL<C>)this.papa;
      desva = this;
      newp = (NodoAVL<C>)this.hijoI;
      sub = (NodoAVL<C>)newp.hijoD;
      newp.papa = pd;
      pd.hijoD = newp;
      desva.papa = newp;
      newp.hijoD = desva;
      desva.hijoI = null;
      if(sub != null) sub.papa = desva;
      return newp;
    }else{
      desva = this;
      newp = (NodoAVL<C>)this.hijoI;
      sub = (NodoAVL<C>)newp.hijoD;
      desva.papa = (NodoAVL<C>)newp;
      newp.hijoD = desva;
      desva.hijoI = null;
      newp.papa = null;
      if(sub != null) sub.papa = desva;
      return newp;
    }
  }

  public NodoAVL<C> rotaLL(){
    NodoAVL <C> pd;
    NodoAVL <C> desva;
    NodoAVL <C> newp;
    NodoAVL <C> sub;
    if(this.papa != null){
      pd = (NodoAVL<C>)this.papa;
      desva = this;
      newp = (NodoAVL<C>)this.hijoD;
      sub = (NodoAVL<C>)newp.hijoI;
      newp.papa = pd;
      pd.hijoI = newp;
      desva.papa = newp;
      newp.hijoD = desva;
      desva.hijoI = null;
      if(sub != null) sub.papa = desva;
      return newp;
    }else{
      desva = this;
      newp = (NodoAVL<C>)this.hijoI;
      sub = (NodoAVL<C>)newp.hijoD;
      desva.papa = newp;
      newp.hijoD = desva;
      desva.hijoI = null;
      newp.papa = null;
      if(sub != null) sub.papa = desva;
      return newp;
    }
  }

  public NodoAVL<C> removerAVL(NodoAVL<C> h){
    NodoAVL<C> aux = (NodoAVL<C>)h;
    if(aux.esHoja()){
      NodoAVL<C> padre = (NodoAVL<C>)aux.papa;
      aux.papa = null;
      aux.elem = null;
      if(padre.hijoI == aux) padre.hijoI = null;
      else padre.hijoD = null;
      return padre.balanceo();
    }else{
      C swap;
      NodoAVL<C> auxi;
      NodoAVL<C> avl;
      if(aux.hijoI != null){
        if(aux.hijoD == null) auxi = (NodoAVL <C>)aux.hijoI.der();
        else auxi = (NodoAVL <C>)aux.hijoI.izq();
        swap = aux.elem;
        aux.elem = auxi.elem;
        auxi.elem = swap;
        avl = (NodoAVL<C>)auxi.papa;
        return avl.removerAVL((NodoAVL<C>)auxi);
      }else{
        if(aux.hijoD != null){
          auxi = (NodoAVL<C>)aux.hijoD;
          auxi = (NodoAVL<C>)auxi.izq();
          swap = aux.elem;
          aux.elem = auxi.elem;
          auxi.elem = swap;
          avl = (NodoAVL<C>)auxi.papa;
          return avl.removerAVL((NodoAVL<C>)auxi);
        }
      }
    }
    return null;
  }

  public NodoAVL <C> balanceo(){
    NodoAVL<C> aux = this;
    NodoAVL<C> newp = null;
    NodoAVL<C> avl;
    while(aux != null){
      if(aux.getFB() == 2){
        avl = (NodoAVL<C>)aux.hijoI;
        if(avl.getFB() == 1 || avl.getFB() == 0) newp = aux.rotaRR();
        else if(avl.getFB() == -1){
          newp = avl.rotaLL();
          newp = (NodoAVL<C>)newp.papa;
          newp = newp.rotaRR();
        }
      }
      if(aux.getFB() == -2){
        avl = (NodoAVL<C>)aux.hijoD;
        if(avl.getFB() == -1 || avl.getFB() == 0) newp = aux.rotaLL();
        else if(avl.getFB() == 1){
          newp = avl.rotaRR();
          newp = (NodoAVL<C>)newp.papa;
          newp = newp.rotaLL();
        }
      }
      aux = (NodoAVL<C>)aux.papa;
    }
    return newp;
  }

}
