package ed.estructuras.nolineales;

public class ÁrbolAVL<C extends Comparable<C>> extends ÁrbolBOLigado<C>{

  public ÁrbolAVL(){
    raiz = null;
  }

  protected NodoBinario<C> creaNodo(C dato, NodoBinario<C> padre, NodoBinario<C> hijoI, NodoBinario<C> hijoD){
    return new NodoAVL((NodoAVL<C>)hijoI, (NodoAVL<C>)padre, dato, (NodoAVL<C>)hijoD);
  }

  @Override
  public boolean remove(C o) throws NullPointerException{
    if(o == null) throw new NullPointerException();
    NodoAVL<C> aux = (NodoAVL<C>)this.raiz;
    aux = (NodoAVL<C>)aux.busca(o);
    if(aux.esHoja() && this.raiz == aux){
      this.raiz = null;
      return true;
    }else{
      NodoAVL<C> remo;
      if(aux == raiz){
        remo = aux.removerAVL(aux);
        this.raiz = remo;
        return true;
      }else{
        remo = (NodoAVL<C>)aux.getPadre();
        remo = remo.removerAVL(aux);
        if(remo != null && remo.getPadre() == null) this.raiz = remo;
        return true;
      }
    }
  }

  @Override
  public boolean add(C c){
    if(c == null) throw new NullPointerException();
    if(this.raiz == null) this.raiz = new NodoAVL(null, null, c, null);
    else{
      NodoAVL<C> newa = (NodoAVL<C>)this.raiz.addNodo(c);
      newa = newa.balanceo();
      if(newa != null && newa.getPadre() == null) this.raiz = newa;
    }
    tam ++;
    return true;
  }

}
