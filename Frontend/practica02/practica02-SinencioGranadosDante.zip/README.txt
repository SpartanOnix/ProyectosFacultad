Sinencio Granados Dante Jusepee     316246019

Realiza todos los incisos como los entendi, esta practica si estuvo
muy dificil, me llevo mucha investigacion independiente ya que por ejemplo
tuve que investigar como funciona el jquery ya que lo ocupe pero no se nos 
meciono en ningun lado que debiamos ocuparlo.