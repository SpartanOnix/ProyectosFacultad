Para ejecutar el programa solo se debe ejecutar la linea desde la posicion donde
extraeran el .zip:

python lector.py

Esto ejecutara el programa con los ejemplares que estan en las carpetas:
ejemplares_AV y ejemplares_MS.

Si quieren probar ejemplares creados por ustedes, creenlos deacuerdo a lo expicado en
el pdf y agreguenlos de acuerdo a las carpetas:
-Ejemplares del agente viajero: ejemplares_AV
-Ejemplares del Max Sat: ejemplares_MS