Fundamentos de Bases de Datos
Facultad de Ciencias
EQUIPO FIGHTERS Z

Integrantes:
- Cruz Jiménez Alejandro - 316008488
- Reyes Martínez Antonio - 316184931
- Sandoval Mendoza Antonio - 316075725
- Sinencio Granados Dante Jusepee - 316246019

Se compila y ejecuta Escritor.java y se siguen los 
pasos en pantalla, es recomendable que cuando te 
piden numeros uses numeros y no letras o algun otro 
caracter.
